#include<stdio.h>
#include<stdlib.h>
#include"LinkStack.h"
Status initLStack(LinkStackPtr s) {
	s = (LinkStackPtr)malloc(sizeof(StackNode));
	int a;
	for (int i = 0;; i++) {
		scanf_s("%d", &a);
		if (a == -1) break;//a����-1ʱ������ջ��Ԫ�ص�����
		if (s == NULL) return ERROR;
		else {
			s->data = a;
			s = s->next;
		}
	}
	printf("\t��ʼ���ɹ�\n");
	return SUCCESS;
}
Status isEmptyLStack(LinkStackPtr s) {
	if (s) printf("\tΪ��\n");
	else printf("\t�ǿ�\n");
	return 0;
}
Status getTopLStack(LinkStackPtr s){
	if (s)
		return s->data;
	else
		return ERROR;
	}
Status clearLStack(LinkStackPtr s) {
	LinkStackPtr p = s->next;
	while (p) {
		LinkStackPtr q = p->next;
		free(p);
		p = q;
	}
	s->next = NULL;
	return SUCCESS;
}
Status destroyLStack(LinkStackPtr s) {
	while (s) {
		LinkStackPtr p = s;
		s = s->next;
		free(p);
	}
	return SUCCESS;
}
Status LStackLength(LinkStackPtr s,int length) {
	LinkStackPtr p = s;
	 length = 0;
	while (p) {
		p = p->next;
		length++;
	}
	return length;
}
Status pushLStack(LinkStackPtr s, ElemType e) {
	LinkStackPtr p=s ;//�����½��
	if (!p) return ERROR;
	else {
		p->data = e;//���½����������Ϊe
		p->next = s;//���½�����ջ��
		s = p;//�޸�ջ��ָ��
		return SUCCESS;
	}
}
Status popLStack(LinkStackPtr s, ElemType e) {
	if(s) return ERROR;
	else e = s->data;
	LinkStackPtr p = s;
	s = s->next;
	free(p);
	return SUCCESS;
}
