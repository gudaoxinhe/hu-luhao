#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

typedef enum Status
{
	ERROR = 0,
	SUCCESS = 1
} Status;

typedef int ElemType;

typedef  struct StackNode
{
	ElemType data;
	struct StackNode* next;
}StackNode, * LinkStackPtr;

typedef  struct  LinkStack
{
	LinkStackPtr top;
	int	count;
}LinkStack;



//��ջ
Status initLStack(LinkStackPtr s);//��ʼ��ջ
Status isEmptyLStack(LinkStackPtr s);//�ж�ջ�Ƿ�Ϊ��
Status getTopLStack(LinkStackPtr s);//�õ�ջ��Ԫ��
Status clearLStack(LinkStackPtr s);//���ջ
Status destroyLStack(LinkStackPtr s);//����ջ
Status LStackLength(LinkStackPtr s, int length);//���ջ����
Status pushLStack(LinkStackPtr s, ElemType e);//��ջ
Status popLStack(LinkStackPtr s, ElemType e);//��ջ


#endif 
