#include<stdio.h>
#include<stdlib.h>
#include"dulinkedlist.h"
DuLinkedList L;
int main(void)
{
	int i[10] = { 1,2,3,4,5,6,7,8,9,10 };
		int j = 3,a=2,b=3,c=4,d=5;
	Status InitList_DuL(DuLinkedList L, int i[10]);
	printf("���������������\n");
	Status InsertBeforeList_DuL(L,a,c);
	Status InsertAfterList_DuL(L,b,d);
	printf("ɾ����3�����\n");
	Status DeleteList_DuL(L,j);
	void TraverseList_DuL(DuLinkedList L, void (*visit)(int i, ElemType e));
	void DestroyList_DuL(DuLinkedList * L);
	return 0;
}