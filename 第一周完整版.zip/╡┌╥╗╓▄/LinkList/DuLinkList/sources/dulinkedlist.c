#include<stdio.h>
#include<stdlib.h>
#include"dulinkedlist.h"
Status InitList_DuL(DuLinkedList L,int n) {
	int i;
	DuLinkedList p = NULL;
	DuLinkedList q = NULL;
	p = (DuLinkedList)malloc(sizeof(DuLNode));
	if (!p) {
		exit(OVERFLOW);
	}
	p = L;
	p->data = 0;//��������ʼ��
	p->prior = NULL;
	p->next = NULL;
	for (i = 0; i < n; i++) {//��������ֵ
		q = (DuLinkedList)malloc(sizeof(DuLNode));
		if (!q) { exit(OVERFLOW); }
		q->data = i + 1;
		q->prior = p;
		p->next = q;
		p = q;
	}
	return SUCCESS;
}
void DestroyList_DuL(DuLinkedList L) {
	DuLinkedList p = NULL;
	p = (DuLinkedList)malloc(sizeof(DuLNode));
	if (!p||!L) { exit(OVERFLOW); }
	while (L) {
		p = L->next;
		free(L);
		L = p;
	}
}
Status InsertBeforeList_DuL(DuLinkedList L,int n,ElemType e) {
	DuLNode* p;
	DuLNode* q=L;
	p = (DuLinkedList)malloc(sizeof(DuLNode));
	p = L;
	int i=0;
	while ((p!=NULL) && i < n ) {
		i++;
		p = p->next;
	}
	if (!p) {
		return ERROR;
	}
	if (!q) { return ERROR; }
	q = (DuLinkedList)malloc(sizeof(DuLinkedList));
	if (q) {
		q->data = e;
		q->prior = p->prior;
		p->prior->next = q;
		p = q->next;
		p->prior = q;
		return	SUCCESS;
	}
	printf("������λ��Ϊ%d\n", n);
	printf("��������Ϊ%d\n",e);
}
Status InsertAfterList_DuL(DuLinkedList L, int n, ElemType e) {
	DuLNode* p;
	DuLNode* q=L;
	p = (DuLinkedList)malloc(sizeof(DuLNode));
	p = L;
	int i = 0;
	while ((p != NULL) && i < n - 1) {
		i++;
		p = p->next;
	}
	if (!p) {
		return ERROR;
	}
	if (!q) { return ERROR; }
	q = (DuLinkedList)malloc(sizeof(DuLinkedList));
	if (q) {
		q->data = e;
		q = p->next->prior;
		p->next = q->next;
		p->next->prior = q;
		p = q->prior;
		p->next = q;
		return SUCCESS;
	}
	else 
	{
	exit(OVERFLOW);
	 }
	 printf("������λ��Ϊ%d\n", n);
	 printf("��������Ϊ%d\n", e);
}
Status DeleteList_DuL(DuLinkedList L,int i) {
	DuLNode* p=L->next;
	int j = 0;
	while (p != NULL && j <= i) {
		p = p->next;
		j++;
	}
	if (!p) {
		return ERROR;
	}
	p->prior->next = p->next;
	p->next->prior = p->prior;
	free(p);
	return SUCCESS;
}
void visit(int i, ElemType e);
void TraverseList_DuL(DuLinkedList L, void visit(int i,ElemType e)) {
	int j = 0;
	while(L) {
		printf("��ǰ������Ϊ%d\n", j);
		printf("��ǰ�������Ϊ%d\n", L->data);
		j++;
	}
	if (!L) { return ERROR; }
	return SUCCESS;
}
void visit(int i, DuLNode* p, ElemType e){
	int j = 0;
	p = (DuLinkedList)malloc(sizeof(DuLNode));
	while (p != NULL && j <= i) {
		p = p->next;
		j++;
	}
	if (!p || j > i) { exit(OVERFLOW); }
	e = p->data;
	return SUCCESS;
}