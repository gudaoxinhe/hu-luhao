#include<stdio.h>
#include<stdlib.h>
#include"linkedlist.h"
struct LNode* L;//�������L

Status InitList(LinkedList L,int n) {
	L = (LinkedList)malloc(sizeof(LNode));//�����ڴ�
	if (!L) {
		exit(OVERFLOW);//�˳�
	}
	L->next = NULL;
	int i;
	L->next = NULL;
	for (i = 0; i < n; i++) {
		LinkedList p = (LinkedList)malloc(sizeof(LNode));
		if (p) {
			scanf_s(&p->data);
			p->next = L->next;
			L->next = p;
		}
	}
}
Status InsertList(LNode* p, int i, ElemType e) {
	int j = 0;
	p = L;
	p = (LinkedList)malloc(sizeof(LNode));
	while (p!=NULL && j < i)
	{
		p = p->next;
		j++;
	}
	LNode* q;
	if (p == NULL)
		return ERROR;
	else
	{
		q = (LinkedList)malloc(sizeof(LNode));
		if (!q) {
			exit(OVERFLOW);
		}
		q->data = e;
		q->next = p->next;
		p->next = q;
		return SUCCESS;
	}
	printf("q�����Ϊ%d\n", i);
	printf("q������Ϊ%d\n", q->data);
	return 0;
}
	Status DeleteList(LNode * p, ElemType  e){
	int i, j = 0;
	scanf_s("%d", &i);
	LinkedList q;
	p = L;
	while (p->next && j < i - 1)
	{
		p = p->next;
		++j;
	}
	if (!(p->next) || j > i - 1)
		return ERROR;
	q = p->next;
	p->next = q->next;//ai-1->ai+1
	free (q);//ɾ����i�����
	return SUCCESS;
   }
	void DestroyList(LinkedList L){
	
		LinkedList q;
			q= L;
		while (L)
		{
			LinkedList p = q;
			q = q->next;
			free(p);
			p = NULL;
		}
		return SUCCESS;
	}
	void visit(int i, ElemType e);
	void TraverseList_DuL(LinkedList L, void visit(int i, ElemType e)) {
		int j = 0;
		while (L) {
			printf("��ǰ������Ϊ%d\n", j);
			printf("��ǰ�������Ϊ%d\n", L->data);
			j++;
		}
		if (!L) { return ERROR; }
		return SUCCESS;
	}
	void visit(int i, ElemType e) {

		LinkedList p=(LinkedList)malloc(sizeof(LNode));
		p = L->next;
		int j = 0;
		while (p != NULL && j <= i) {
			p = p->next;
			j++;
		}
		if (!p || j > i) { exit(OVERFLOW); }
		e = p->data;
		return SUCCESS;
	}
		Status SearchList(LinkedList L, ElemType e){
		int j = 1;
		int i;
		scanf_s("%d", &i);
		LinkedList p;
		p = L->next;			//��struct LNode *p = L->next;
		while (p && j < i)
		{
			p = p->next;
			++j;
		}
		if (!p || j > i)
			return ERROR;
		e = p->data;
		return SUCCESS;
	}
		Status IsLoopList(LinkedList L){
		if (L == NULL) {
			exit(OVERFLOW);
		}
		LinkedList slow = L->next;//��ʼ��Ϊ��һ�����
		if (!slow) {
			exit(OVERFLOW);
		}
		LinkedList fast = slow->next;//��ʼ��Ϊ�ڶ������
		slow = fast = L->next;
		while (slow != NULL && fast != NULL) {
			slow = slow->next;//��ָ����һ��
			fast = fast->next;//��ָ��������
			if (fast) {
				fast = fast->next;
			}
			if (slow == fast) {
				printf("��ѭ������\n");
			}
		}
		if (slow != fast) {
			printf("����ѭ������\n");
		}
		return 0;
	}
